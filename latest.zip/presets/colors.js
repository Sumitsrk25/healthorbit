export const COLOR_PRESETS = {
  PRIMARY: {
    DARK: "#3959AA",
    BASE: "#9ABCF7",
    LIGHT: "#EFF5FD",
  },
  DARK: {
    BLACK: "#00000",
  },
  LIGHT:{
    WHITE: "#ffffff",
  }
};
