const HealthOrbitImage = require('./images/health_orbit.png')

export {
  HealthOrbitImage,
}